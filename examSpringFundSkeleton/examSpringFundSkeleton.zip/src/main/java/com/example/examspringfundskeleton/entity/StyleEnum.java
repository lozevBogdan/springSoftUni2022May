package com.example.examspringfundskeleton.entity;

public enum StyleEnum {
    POP, ROCK, JAZZ
}
