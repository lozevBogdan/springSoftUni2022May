package com.example.examspringfundskeleton;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExamSpringFundSkeletonApplication {

    public static void main(String[] args) {
        SpringApplication.run(ExamSpringFundSkeletonApplication.class, args);
    }

}
